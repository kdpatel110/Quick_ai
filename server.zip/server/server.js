import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import { clerkMiddleware, requireAuth} from '@clerk/express'
import aiRouter from './routes/aiRoutes.js';
import connectCloudinary from './configs/cloudinary.js';
import userRouter from './routes/userRoutes.js';


const app = express()

await connectCloudinary()

// CORS (VERY IMPORTANT)
app.use(cors({
  origin: "http://localhost:5173",   // your frontend
  credentials: true,                  // allow cookies
}));

// //Middleware
// app.use(cors({
//   origin: "*",
//   methods: ["GET", "POST", "PUT", "DELETE"],
//   allowedHeaders: ["Content-Type", "Authorization"]
// }));

app.use(express.json()) 
app.use(clerkMiddleware())

app.get('/', (req, res)=> res.send('server is Live!'))
// app.use(requireAuth())

import { getAuth } from "@clerk/express";

app.get("/debug", (req, res) => {
  const auth = getAuth(req);
  console.log("DEBUG AUTH:", auth);
  res.json(auth);
});


app.use('/api/ai', aiRouter)
app.use('/api/user', userRouter)

const PORT = process.env.PORT || 3000;

app.listen(PORT, ()=>{
    console.log('server is running on port', PORT);
})



